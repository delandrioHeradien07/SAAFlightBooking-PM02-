﻿using System;
using Microsoft.Data.SqlClient;

namespace SAABookingApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString =
                "Server=localhost;Database=SAAFlightBookingDB;Trusted_Connection=True;TrustServerCertificate=True;";

            string query = "SELECT * FROM Passengers";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    Console.WriteLine("======================================");
                    Console.WriteLine("  SAA Flight Booking System");
                    Console.WriteLine("======================================");
                    Console.WriteLine("Database connection established successfully!");
                    Console.WriteLine();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        Console.WriteLine("Passenger Records:");
                        Console.WriteLine("--------------------------------------");

                        while (reader.Read())
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                Console.Write($"{reader.GetName(i)}: {reader[i]}  ");
                            }

                            Console.WriteLine();
                            Console.WriteLine("--------------------------------------");
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Database connection failed.");
                Console.WriteLine($"Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An unexpected error occurred.");
                Console.WriteLine($"Error: {ex.Message}");
            }

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}