USE SAAFlightBookingDB;
GO

SELECT
    p.PassengerID,
    p.FirstName,
    p.LastName,
    p.Email,
    b.BookingID,
    b.BookingStatus,
    f.FlightNumber,
    departure.City AS DepartureCity,
    arrival.City AS ArrivalCity,
    f.DepartureDateTime
FROM Passengers p
INNER JOIN BookingPassengers bp
    ON p.PassengerID = bp.PassengerID
INNER JOIN Bookings b
    ON bp.BookingID = b.BookingID
INNER JOIN Flights f
    ON b.FlightID = f.FlightID
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
ORDER BY p.LastName, p.FirstName;
GO

SELECT
    f.FlightNumber,
    departure.City AS DepartureCity,
    arrival.City AS ArrivalCity,
    f.DepartureDateTime,
    p.PassengerID,
    p.FirstName,
    p.LastName,
    p.Email
FROM Flights f
INNER JOIN Bookings b
    ON f.FlightID = b.FlightID
INNER JOIN BookingPassengers bp
    ON b.BookingID = bp.BookingID
INNER JOIN Passengers p
    ON bp.PassengerID = p.PassengerID
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
WHERE b.BookingStatus = 'CONFIRMED'
ORDER BY f.FlightNumber, p.LastName;
GO

SELECT
    f.FlightNumber,
    departure.City AS DepartureCity,
    arrival.City AS ArrivalCity,
    SUM(p.Amount) AS TotalRevenue
FROM Flights f
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
LEFT JOIN Bookings b
    ON f.FlightID = b.FlightID
LEFT JOIN Payments p
    ON b.BookingID = p.BookingID
WHERE p.PaymentStatus = 'PAID'
GROUP BY
    f.FlightNumber,
    departure.City,
    arrival.City
ORDER BY TotalRevenue DESC;
GO

SELECT
    f.FlightNumber,
    departure.City AS DepartureCity,
    arrival.City AS ArrivalCity,
    COUNT(t.TicketID) AS TicketsIssued
FROM Flights f
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
LEFT JOIN Bookings b
    ON f.FlightID = b.FlightID
LEFT JOIN Tickets t
    ON b.BookingID = t.BookingID
    AND t.TicketStatus = 'ISSUED'
GROUP BY
    f.FlightNumber,
    departure.City,
    arrival.City
ORDER BY f.FlightNumber;
GO

SELECT
    BookingStatus,
    COUNT(*) AS NumberOfBookings
FROM Bookings
GROUP BY BookingStatus
ORDER BY BookingStatus;
GO

SELECT
    COUNT(DISTINCT b.BookingID) AS TotalBookings,
    COUNT(DISTINCT bp.PassengerID) AS TotalPassengers,
    COUNT(DISTINCT t.TicketID) AS TotalTickets,
    SUM(
        CASE
            WHEN pay.PaymentStatus = 'PAID'
            THEN pay.Amount
            ELSE 0
        END
    ) AS TotalRevenue
FROM Bookings b
LEFT JOIN BookingPassengers bp
    ON b.BookingID = bp.BookingID
LEFT JOIN Tickets t
    ON b.BookingID = t.BookingID
LEFT JOIN Payments pay
    ON b.BookingID = pay.BookingID;
GO

SELECT
    f.FlightNumber,
    departure.City AS DepartureCity,
    arrival.City AS ArrivalCity,
    b.BookingID,
    b.BookingStatus
FROM Flights f
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
LEFT JOIN Bookings b
    ON f.FlightID = b.FlightID
ORDER BY f.FlightNumber;
GO
