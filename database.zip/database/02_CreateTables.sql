USE SAAFlightBookingDB;
GO

CREATE TABLE Airports
(
    AirportID INT IDENTITY(1,1) NOT NULL,
    AirportCode VARCHAR(10) NOT NULL,
    AirportName VARCHAR(100) NOT NULL,
    City VARCHAR(100) NOT NULL,

    CONSTRAINT PK_Airports
        PRIMARY KEY (AirportID),

    CONSTRAINT UQ_Airports_AirportCode
        UNIQUE (AirportCode)
);
GO

CREATE TABLE Passengers
(
    PassengerID INT IDENTITY(1,1) NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Phone VARCHAR(20) NOT NULL,

    CONSTRAINT PK_Passengers
        PRIMARY KEY (PassengerID),

    CONSTRAINT UQ_Passengers_Email
        UNIQUE (Email)
);
GO

CREATE TABLE Flights
(
    FlightID INT IDENTITY(1,1) NOT NULL,
    FlightNumber VARCHAR(20) NOT NULL,
    DepartureAirportID INT NOT NULL,
    ArrivalAirportID INT NOT NULL,
    DepartureDateTime DATETIME NOT NULL,
    ArrivalDateTime DATETIME NOT NULL,

    CONSTRAINT PK_Flights
        PRIMARY KEY (FlightID),

    CONSTRAINT UQ_Flights_FlightNumber
        UNIQUE (FlightNumber),

    CONSTRAINT FK_Flights_DepartureAirport
        FOREIGN KEY (DepartureAirportID)
        REFERENCES Airports(AirportID),

    CONSTRAINT FK_Flights_ArrivalAirport
        FOREIGN KEY (ArrivalAirportID)
        REFERENCES Airports(AirportID),

    CONSTRAINT CK_Flights_Airports
        CHECK (DepartureAirportID <> ArrivalAirportID),

    CONSTRAINT CK_Flights_DateTime
        CHECK (ArrivalDateTime > DepartureDateTime)
);
GO

CREATE TABLE Bookings
(
    BookingID INT IDENTITY(1,1) NOT NULL,
    FlightID INT NOT NULL,
    BookingDate DATETIME NOT NULL DEFAULT GETDATE(),
    BookingStatus VARCHAR(20) NOT NULL,

    CONSTRAINT PK_Bookings
        PRIMARY KEY (BookingID),

    CONSTRAINT FK_Bookings_Flight
        FOREIGN KEY (FlightID)
        REFERENCES Flights(FlightID),

    CONSTRAINT CK_Bookings_Status
        CHECK (BookingStatus IN ('CONFIRMED', 'CANCELLED', 'PENDING'))
);
GO

CREATE TABLE BookingPassengers
(
    BookingPassengerID INT IDENTITY(1,1) NOT NULL,
    BookingID INT NOT NULL,
    PassengerID INT NOT NULL,

    CONSTRAINT PK_BookingPassengers
        PRIMARY KEY (BookingPassengerID),

    CONSTRAINT FK_BookingPassengers_Booking
        FOREIGN KEY (BookingID)
        REFERENCES Bookings(BookingID),

    CONSTRAINT FK_BookingPassengers_Passenger
        FOREIGN KEY (PassengerID)
        REFERENCES Passengers(PassengerID),

    CONSTRAINT UQ_BookingPassengers
        UNIQUE (BookingID, PassengerID)
);
GO

CREATE TABLE Tickets
(
    TicketID INT IDENTITY(1,1) NOT NULL,
    BookingID INT NOT NULL,
    TicketNumber VARCHAR(30) NOT NULL,
    IssueDate DATETIME NOT NULL DEFAULT GETDATE(),
    TicketStatus VARCHAR(20) NOT NULL,

    CONSTRAINT PK_Tickets
        PRIMARY KEY (TicketID),

    CONSTRAINT FK_Tickets_Booking
        FOREIGN KEY (BookingID)
        REFERENCES Bookings(BookingID),

    CONSTRAINT UQ_Tickets_TicketNumber
        UNIQUE (TicketNumber),

    CONSTRAINT CK_Tickets_Status
        CHECK (TicketStatus IN ('ISSUED', 'CANCELLED'))
);
GO

CREATE TABLE Payments
(
    PaymentID INT IDENTITY(1,1) NOT NULL,
    BookingID INT NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    PaymentDate DATETIME NOT NULL DEFAULT GETDATE(),
    PaymentStatus VARCHAR(20) NOT NULL,

    CONSTRAINT PK_Payments
        PRIMARY KEY (PaymentID),

    CONSTRAINT FK_Payments_Booking
        FOREIGN KEY (BookingID)
        REFERENCES Bookings(BookingID),

    CONSTRAINT CK_Payments_Amount
        CHECK (Amount > 0),

    CONSTRAINT CK_Payments_Status
        CHECK (PaymentStatus IN ('PAID', 'PENDING', 'REFUNDED'))
);
GO
