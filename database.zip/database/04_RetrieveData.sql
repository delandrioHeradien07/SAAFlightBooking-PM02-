USE SAAFlightBookingDB;
GO

SELECT
    PassengerID,
    FirstName,
    LastName,
    Email,
    Phone
FROM Passengers
ORDER BY PassengerID;
GO

SELECT
    FlightID,
    FlightNumber,
    DepartureAirportID,
    ArrivalAirportID,
    DepartureDateTime,
    ArrivalDateTime
FROM Flights
ORDER BY FlightID;
GO

SELECT
    b.BookingID,
    b.FlightID,
    b.BookingDate,
    b.BookingStatus,
    p.PaymentID,
    p.Amount,
    p.PaymentDate,
    p.PaymentStatus
FROM Bookings b
LEFT JOIN Payments p
    ON b.BookingID = p.BookingID
ORDER BY b.BookingID;
GO

SELECT
    f.FlightID,
    f.FlightNumber,
    departure.AirportCode AS DepartureAirport,
    departure.City AS DepartureCity,
    arrival.AirportCode AS ArrivalAirport,
    arrival.City AS ArrivalCity,
    f.DepartureDateTime,
    f.ArrivalDateTime
FROM Flights f
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
WHERE departure.City = 'Johannesburg'
ORDER BY f.DepartureDateTime;
GO

SELECT
    f.FlightID,
    f.FlightNumber,
    departure.AirportCode AS DepartureAirport,
    departure.City AS DepartureCity,
    arrival.AirportCode AS ArrivalAirport,
    arrival.City AS ArrivalCity,
    f.DepartureDateTime,
    f.ArrivalDateTime
FROM Flights f
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
WHERE arrival.City = 'Cape Town'
ORDER BY f.ArrivalDateTime;
GO

SELECT
    p.PassengerID,
    p.FirstName,
    p.LastName,
    p.Email,
    b.BookingID,
    b.BookingStatus,
    f.FlightNumber,
    departure.City AS DepartureCity,
    arrival.City AS ArrivalCity,
    f.DepartureDateTime,
    f.ArrivalDateTime
FROM Passengers p
INNER JOIN BookingPassengers bp
    ON p.PassengerID = bp.PassengerID
INNER JOIN Bookings b
    ON bp.BookingID = b.BookingID
INNER JOIN Flights f
    ON b.FlightID = f.FlightID
INNER JOIN Airports departure
    ON f.DepartureAirportID = departure.AirportID
INNER JOIN Airports arrival
    ON f.ArrivalAirportID = arrival.AirportID
ORDER BY p.PassengerID;
GO
