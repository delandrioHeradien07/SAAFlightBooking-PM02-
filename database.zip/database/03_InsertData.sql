USE SAAFlightBookingDB;
GO

INSERT INTO Airports
(
    AirportCode,
    AirportName,
    City
)
VALUES
('JNB', 'O.R. Tambo International Airport', 'Johannesburg'),
('CPT', 'Cape Town International Airport', 'Cape Town'),
('DUR', 'King Shaka International Airport', 'Durban');
GO

INSERT INTO Passengers
(
    FirstName,
    LastName,
    Email,
    Phone
)
VALUES
('Thabo', 'Mokoena', 'thabo.mokoena@email.com', '0821112233'),
('Lerato', 'Nkosi', 'lerato.nkosi@email.com', '0832223344'),
('Daniel', 'Smith', 'daniel.smith@email.com', '0843334455'),
('Ayesha', 'Patel', 'ayesha.patel@email.com', '0854445566'),
('Michael', 'Williams', 'michael.williams@email.com', '0865556677');
GO

INSERT INTO Flights
(
    FlightNumber,
    DepartureAirportID,
    ArrivalAirportID,
    DepartureDateTime,
    ArrivalDateTime
)
VALUES
(
    'SA101',
    (SELECT AirportID FROM Airports WHERE AirportCode = 'JNB'),
    (SELECT AirportID FROM Airports WHERE AirportCode = 'CPT'),
    '2026-10-01 08:00:00',
    '2026-10-01 10:15:00'
),
(
    'SA102',
    (SELECT AirportID FROM Airports WHERE AirportCode = 'CPT'),
    (SELECT AirportID FROM Airports WHERE AirportCode = 'JNB'),
    '2026-10-02 11:00:00',
    '2026-10-02 13:15:00'
),
(
    'SA103',
    (SELECT AirportID FROM Airports WHERE AirportCode = 'JNB'),
    (SELECT AirportID FROM Airports WHERE AirportCode = 'DUR'),
    '2026-10-03 09:30:00',
    '2026-10-03 10:35:00'
),
(
    'SA104',
    (SELECT AirportID FROM Airports WHERE AirportCode = 'DUR'),
    (SELECT AirportID FROM Airports WHERE AirportCode = 'JNB'),
    '2026-10-04 14:00:00',
    '2026-10-04 15:05:00'
),
(
    'SA105',
    (SELECT AirportID FROM Airports WHERE AirportCode = 'JNB'),
    (SELECT AirportID FROM Airports WHERE AirportCode = 'CPT'),
    '2026-10-05 16:30:00',
    '2026-10-05 18:45:00'
);
GO

INSERT INTO Bookings
(
    FlightID,
    BookingDate,
    BookingStatus
)
VALUES
(
    (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA101'),
    '2026-09-20 09:00:00',
    'CONFIRMED'
),
(
    (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA102'),
    '2026-09-21 10:30:00',
    'CONFIRMED'
),
(
    (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA103'),
    '2026-09-22 14:00:00',
    'PENDING'
);
GO

INSERT INTO BookingPassengers
(
    BookingID,
    PassengerID
)
VALUES
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA101')),
    (SELECT PassengerID FROM Passengers WHERE Email = 'thabo.mokoena@email.com')
),
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA101')),
    (SELECT PassengerID FROM Passengers WHERE Email = 'lerato.nkosi@email.com')
),
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA102')),
    (SELECT PassengerID FROM Passengers WHERE Email = 'daniel.smith@email.com')
),
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA103')),
    (SELECT PassengerID FROM Passengers WHERE Email = 'ayesha.patel@email.com')
);
GO

INSERT INTO Tickets
(
    BookingID,
    TicketNumber,
    IssueDate,
    TicketStatus
)
VALUES
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA101')),
    'TKT-10001',
    '2026-09-20 09:15:00',
    'ISSUED'
),
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA102')),
    'TKT-10002',
    '2026-09-21 10:45:00',
    'ISSUED'
),
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA103')),
    'TKT-10003',
    '2026-09-22 14:15:00',
    'ISSUED'
);
GO

INSERT INTO Payments
(
    BookingID,
    Amount,
    PaymentDate,
    PaymentStatus
)
VALUES
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA101')),
    1850.00,
    '2026-09-20 09:20:00',
    'PAID'
),
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA102')),
    2100.00,
    '2026-09-21 10:50:00',
    'PAID'
),
(
    (SELECT BookingID FROM Bookings WHERE FlightID =
        (SELECT FlightID FROM Flights WHERE FlightNumber = 'SA103')),
    1650.00,
    '2026-09-22 14:20:00',
    'PENDING'
);
GO
