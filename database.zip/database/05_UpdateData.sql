USE SAAFlightBookingDB;
GO

SELECT PassengerID, FirstName, LastName, Email
FROM Passengers
WHERE PassengerID = 1;
GO

UPDATE Passengers
SET Email = 'thabo.mokoena.updated@email.com'
WHERE PassengerID = 1;
GO

SELECT PassengerID, FirstName, LastName, Email
FROM Passengers
WHERE PassengerID = 1;
GO

SELECT BookingID, FlightID, BookingDate, BookingStatus
FROM Bookings
WHERE BookingID = 3;
GO

UPDATE Bookings
SET BookingStatus = 'CONFIRMED'
WHERE BookingID = 3;
GO

SELECT BookingID, FlightID, BookingDate, BookingStatus
FROM Bookings
WHERE BookingID = 3;
GO

SELECT PaymentID, BookingID, Amount, PaymentStatus
FROM Payments
WHERE PaymentID = 3;
GO

UPDATE Payments
SET PaymentStatus = 'PAID'
WHERE PaymentID = 3;
GO

SELECT PaymentID, BookingID, Amount, PaymentStatus
FROM Payments
WHERE PaymentID = 3;
GO
