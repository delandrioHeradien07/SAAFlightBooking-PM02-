USE SAAFlightBookingDB;
GO

SELECT
    BookingID,
    FlightID,
    BookingDate,
    BookingStatus
FROM Bookings
WHERE BookingID = 1;
GO

SELECT *
FROM BookingPassengers
WHERE BookingID = 1;
GO

SELECT *
FROM Tickets
WHERE BookingID = 1;
GO

SELECT *
FROM Payments
WHERE BookingID = 1;
GO

DELETE FROM Bookings
WHERE BookingID = 1;
GO
